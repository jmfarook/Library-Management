import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import LibraryBooks from "@material-ui/icons/LibraryBooks"

import store from "../store/index";


const styles = {
  appbar: {
    alignItems: 'center',
  }
};
class SimpleAppBar extends React.Component {
  state = {
    checked: []
  };



  render() {
    const { classes } = this.props;

    return (
      <AppBar className={classes.appbar} position="static" color="default">
        <Toolbar>
          <Typography variant="title" color="secondary" align='center'>
          Library management System
          <LibraryBooks/>
          </Typography>
        </Toolbar>
      </AppBar>
    );
  }
}

SimpleAppBar.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(SimpleAppBar);
