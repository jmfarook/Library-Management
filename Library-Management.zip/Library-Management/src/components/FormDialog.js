import React from "react";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import store from "../store/index";
import { CLOSE_FORM } from "../constants/action-types";
import { ADD_ARTICLE } from "../constants/action-types";
window.store = store;

export default class FormDialog extends React.Component {
  state = {
    open: false,
    bookName: '',
    description:'',
    authorName: '',
    bkerror:'',
    deserror:'',
    auterror:'',
  };

  handleClose = () => {
    store.dispatch({
      type: CLOSE_FORM,
      payload: {
        openFormDialog: false
      }
    });
  };

  handleChange = name => event => {
    this.setState({
      article: event.target.value
    });
  };

  handleSave = () => {

    let bkName = document.getElementById('input_bk').value;
    let autName = document.getElementById('input_aut').value;
    let desp = document.getElementById('input_des').value;
    if(bkName ==='' && autName ==='' && desp ===''){
      
      var bkerrorMsg = bkName === '' ? 'Required Book Name': '';
      var deserrorMsg = bkName === '' ? 'Required Description': '';
      var auterrorMsg = bkName === '' ? 'Required Author Name': '';
      this.setState({bkerror:bkerrorMsg, deserror: deserrorMsg, auterror: auterrorMsg});
      return;
    }
    else{
      this.setState({bkerror:'', deserror: '', auterror: ''});
    }

    store.dispatch({
      type: ADD_ARTICLE,
      payload: {
       bookName: bkName,
        author: autName,
        description: desp
      }
    });

    store.dispatch({
      type: CLOSE_FORM
    });
  };

  componentDidMount() {
    this.setState({
      open: store.getState()["uiState"]["openFormDialog"]
    });

    store.subscribe(() => {
      this.setState({
        open: store.getState()["uiState"]["openFormDialog"]
      });
    });
  }

  render() {
    return (
      <div>
        <Dialog
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="form-dialog-title">Add Book Details</DialogTitle>
          <DialogContent>
       
              <List component="div" role="list">
                <ListItem>
                  <TextField required
                    id="input_bk"
                    label="Enter the Book Name"
                    style={{width: 190}}
                    defaultValue=""
                    error ={this.state.bkerror.length>0? true : false}
                    helperText={this.state.bkerror}
                  />
                </ListItem>
                <ListItem>
                  <TextField required
                    id="input_des"
                    label="Enter the Description"
                    multiline
                    style={{width: 190}}
                    rowsMax="5"
                    defaultValue=''
                    error ={this.state.deserror.length>0? true : false}
                    helperText={this.state.deserror}
                  />
                </ListItem>
                <ListItem>

                  <TextField required
                    id="input_aut"
                    label="Enter the AuthorName"
                    style={{width: 190}}
                    defaultValue=""
                    error ={this.state.auterror.length>0? true : false}
                    helperText={this.state.auterror}
                  />
                </ListItem>
              </List>
        
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Cancel
            </Button>
            <Button onClick={this.handleSave} color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}
