import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import store from "../store/index";
import Comment from "@material-ui/icons/Error";
import { OPEN_EDIT_FORM } from "../constants/action-types";
import { SELECT_ARTICLE } from "../constants/action-types";
import { OPEN_FORM } from "../constants/action-types";
import Typography from "@material-ui/core/Typography";
import CardContent from "@material-ui/core/CardContent";
import Card from "@material-ui/core/Card";
import Fab from '@material-ui/core/Fab';
import TextField from "@material-ui/core/TextField";
import Grid from "@material-ui/core/Grid";
import AccountCircle from "@material-ui/icons/Search";
import AddIcon from "@material-ui/icons/Add";
import SelectAll from "@material-ui/icons/SelectAll";
import LibraryBooks from "@material-ui/icons/BookTwoTone";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Tooltip from '@material-ui/core/Tooltip';
window.store = store;


const styles = theme => ({
  ewarn:{
    backgroundColor:'red'
  },
  esucc:{
    backgroundColor: ''
  },
  root: {
    width: "100%",
    height: 360,
    marginTop: 15,
    backgroundColor: theme.palette.background.paper
  },
  avatar: {
    color: "#fff",
    backgroundColor: "#F00"
  },

  tblth: {
    borderTopWidth: 1,
    borderStyle: "solid",
    borderTopColor: "rgba(224, 224, 224, 1)",
    borderLeftWidth: 0,
    borderRightWidth: 0,
    width: 170
  },
  tblshortth: {
    borderTopWidth: 1,
    borderStyle: "solid",
    borderTopColor: "rgba(224, 224, 224, 1)",
    borderLeftWidth: 0,
    borderRightWidth: 0,
    width: 60
  },
  tblshortcel: {
    borderLeftWidth: 0,
    borderRightWidth: 0,
    width: 60
  },

  tbllongth: {
    borderTopWidth: 1,
    borderStyle: "solid",
    borderTopColor: "rgba(224, 224, 224, 1)",
    borderLeftWidth: 0,
    borderRightWidth: 0,
    width: 220
  },

  tbllongcel: {
    borderLeftWidth: 0,
    borderRightWidth: 0,
    width: 220
  },

  tblcel: {
    width: 170,
    borderLeftWidth: 0,
    borderRightWidth: 0,
  },
  tbl: {
    width: '100%',
    minWidth: '360px',
    marginTop: 10,
    maxHeight: '400px'
  }
});


class ListComponent extends React.Component {

  state = {
    items: [],
    searchedResults: [],
    isAdd: false,
    searchAuthr: []
  };

  openEditDialog = () => {

    store.dispatch({
      type: OPEN_EDIT_FORM,

    });
  };

  componentDidMount() {
    this.setState({
      items: store.getState()["articles"],

    });

    store.subscribe(() => {
      const isOpenDlg = store.getState()["uiState"].openFormDialog;
      if (isOpenDlg && this.state.searchedResults.length > 0) {
        this.setState({ items: this.state.searchedResults });
      }
      else {
        if (this.state.searchedResults.length > 0) {
          document.getElementById('search_bk').value = '';
          document.getElementById('search_aut').value = '';
        }
        this.setState({
          items: store.getState()["articles"]

        });
      }
    });
  }

  handleChange = event => {
    var updatedList = store.getState()["articles"];

    updatedList = updatedList.filter(function (item) {
      return item.bookName.toLowerCase().includes(event.target.value.toLowerCase());
    });
    if (updatedList.length === 0 && event.target.value === "") {
      updatedList = store.getState()["articles"];
    }
    this.setState({ items: updatedList, searchedResults: updatedList });
  };
  handleChangeAut = event => {
    var filteredItems = this.state.searchedResults.length > 0 ? this.state.searchedResults : store.getState()["articles"];
    filteredItems = filteredItems.filter(function (item) {
      return item.author.toLowerCase().includes(event.target.value.toLowerCase());
    });

    this.setState({ items: filteredItems });

  }

  handleToggle = value => () => {
    store.dispatch({
      type: SELECT_ARTICLE,
      payload: value
    });
  };

  openDialog = () => {
    this.setState({ isAdd: true });
    store.dispatch({
      type: OPEN_FORM
    });
  };

  render() {
    const { classes } = this.props;
    return (
      <div className={classes.root}>
        <div>
          <div className={'addbtn'}>
            <Tooltip title="Add a New Book">
              <Fab
                color='primary'
                style={{
                  position: "absolute",
                  right: 12,
                  top: 100,
                  width: 40,
                  height: 40
                }}
                onClick={this.openDialog}
                color="secondary"
              >
                <AddIcon />
              </Fab>
            </Tooltip>
          </div>
          <div className={'editbtn'}>
            <Tooltip title="Get a book">
              <Fab
                color='primary'
                style={{
                  position: "absolute",
                  right: 80,
                  top: 100,
                  width: 40,
                  height: 40
                }}
                onClick={this.openEditDialog}
                color="secondary"
              >
                <LibraryBooks />
              </Fab>
            </Tooltip>
          </div>

          <Grid container alignItems="flex-end">

            <Grid item xs={0}>
              <TextField
                id="search_bk"
                label="Search a Book Name"
                onChange={this.handleChange}
                InputProps={{
                  endAdornment: <AccountCircle />
                }}
              />
            </Grid>

            <Grid item xs={4}>
              <TextField
                id="search_aut"
                label="Search a Author"
                onChange={this.handleChangeAut}
                InputProps={{
                  endAdornment: <AccountCircle />
                }}
              />
            </Grid>
           
          </Grid>

        </div>
        {this.state.items.length == 0 ? (

          <Card>
            <CardContent>
              <Comment />

              <Typography color="headline">No Data</Typography>
              <Typography className={classes.pos} color="textSecondary">
                No Article found ¯\_(ツ)_/¯
              </Typography>
            </CardContent>
          </Card>
        ) : (
            <div>
              <div style={{ overflow: "auto" }}>
                <Table className={classes.tbl} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      <TableCell className={classes.tblth}>Name</TableCell>
                      <TableCell className={classes.tbllongth}>Description</TableCell>
                      <TableCell className={classes.tblth}>Author</TableCell>
                      <TableCell align='right' className={classes.tblshortth}>Stock</TableCell>
                    </TableRow>
                  </TableHead>
                </Table>
              </div>
              <div style={{ overflow: 'auto', height: '350px' }}>
                <Table className={classes.tbl} style={{ tableLayout: 'fixed' }}>
                  <TableBody>
                    {this.state.items.map(value => (
                      
                      <TableRow>

                        <TableCell className={classes.tblcel}>{value.bookName}</TableCell>
                        <TableCell className={classes.tbllongcel}>{value.description}</TableCell>
                        <TableCell className={classes.tblcel}>{value.author}</TableCell>
                        <TableCell align='right' className={`${classes.tblshortcel} ${value.count ==0? classes.ewarn:classes.esucc}`}>{value.count}
                        
                        </TableCell>

                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
      </div>
    );
  }
}

ListComponent.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(ListComponent);
