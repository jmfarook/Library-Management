import React from "react";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import AccountCircle1 from "@material-ui/icons/AccountCircle";
import DialogTitle from "@material-ui/core/DialogTitle";
import Autocomplete from '@material-ui/lab/Autocomplete';
import store from "../store/index";
import { CLOSE_EDIT_FORM } from "../constants/action-types";
import { UPDATE_ARTICLE } from "../constants/action-types";
window.store = store;

export default class EditDialog extends React.Component {
  state = {
    open: false,
    items: [],
    filteredBk: [],
    filteredaut: [],
    searchNotApplied: true,
    errorbk: '',
    errorat:'',
    erroruser:'',
    authorName: ''
  };

  handleClose = () => {
    this.setState({searchNotApplied:true, errorbk:'', errorat:'', erroruser:''});
    store.dispatch({
      type: CLOSE_EDIT_FORM
    });
  };


  handleSave = () => {
    let bkerror = document.getElementById('bk-auto').value;
    let auterror = document.getElementById('aut-auto').value;
    let usererror = document.getElementById('txt-us').value;
    if(bkerror === '' && auterror === '' && usererror === '' ){
       let bkerrormsg = bkerror.length===0? 'Need to select any one book':'';
       let auterrormsg = auterror.length===0? 'Need to select any one author':'';
       let usererrormsg = usererror.length===0? 'Need to Enter the User ID':'';
       this.setState({errorbk:bkerrormsg, errorat:auterrormsg, erroruser:usererrormsg});
       return;
    }
    this.setState({searchNotApplied:true, errorbk:'', errorat:'', erroruser:''});
    let currentDate = new Date();
    let validate = currentDate.setDate(currentDate.getDate() +15);
    let returnDate = new Date(validate).toDateString();
    alert('Please remainder you need to return the book on:   ' +  returnDate );
    store.dispatch({
      type: UPDATE_ARTICLE,
      payload: {
      bookName:bkerror,
      author:auterror,
      returnDate : returnDate
      }
    });

    store.dispatch({
      type: CLOSE_EDIT_FORM
    });
  };

  componentDidMount() {
    this.setState({
      open: store.getState()["uiState"]["openEditDialog"],

    });

    store.subscribe(() => {
      this.setState({
        open: store.getState()["uiState"]["openEditDialog"],
        items: store.getState()["articles"]
      });
    });
  }

  onselectBook(event, value) {
    document.getElementById('aut-auto').value = '';
    let bookDetails = store.getState()["articles"];
    let searchResult = bookDetails.filter(art => art.bookName === value);
     this.setState({authorName: searchResult[0].author})
    if(searchResult[0].count === 0){
      document.getElementById('bk-auto').value = '';
      alert("Current the book is not available. So please check with next week's  ");
      return;
    }
    else{
    this.setState({ searchNotApplied: false, filteredBk: searchResult })
    }
  }

  render() {
    return (
      <div>
        <Dialog
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="form-dialog-title">Enter the Book Details</DialogTitle>
          <DialogContent>
          <TextField id='txt-us' required error= {this.state.erroruser.length>0? true: false}
          InputProps={{
            endAdornment: <AccountCircle1 />
          }}
          helperText={this.state.erroruser} style={{ width: 190 }}  label="Enter User ID" />
            <Autocomplete
              style={{ width: 190 }}
              id="bk-auto"
              onChange={this.onselectBook.bind(this)}
              options={this.state.items.map(option => option.bookName)}
              renderInput={params => (
                <TextField {...params} required error= {this.state.errorbk.length>0? true: false}  
                   helperText={this.state.errorbk} label="Search the book" margin="normal" />
              )}
            />

            <Autocomplete
              id="aut-auto"
              style={{ width: 190 }}
              disabled={this.state.searchNotApplied}
              options={this.state.filteredBk.map(option => option.author)}
              value = {this.state.authorName}
              renderInput={params => (
                <TextField {...params} required error= {this.state.errorat.length>0? true: false} helperText={this.state.errorat} label="Selet the author" margin="normal" />
              )}
            />

          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Cancel
            </Button>
            <Button onClick={this.handleSave} color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}
