import { ADD_ARTICLE } from "../constants/action-types";
import { UPDATE_ARTICLE } from "../constants/action-types";
import { OPEN_FORM } from "../constants/action-types";
import { CLOSE_FORM } from "../constants/action-types";
import { OPEN_EDIT_FORM } from "../constants/action-types";
import { CLOSE_EDIT_FORM } from "../constants/action-types";
const initialState = {
  //Read
  articles: [{ bookName: 'C Programming Language', description: 'familiarity with basic programming concepts like variables, assignment statements, loops, and functions.', author: 'Brain W', count: 3 },
  { bookName: 'Clean Code', description: ' A Handbook of Agile Software', author: 'Robert', count: 1 },
  { bookName: 'Code Complete', description: 'Developers write better software for more than a decade', author: 'Steve McConnell', count: 2 },
  { bookName: 'Design Patterns', description: 'Elements of Reusable Object-Oriented Software', author: 'Erich Gamma& Ralph Johnson', count: 2 },
  { bookName: 'Refactoring', description: 'Improving the Design of Existing Code', author: 'Martin Fowler& Kent Beck', count: 5 },
  { bookName: 'The Mythical Man-Month', description: 'Essays on Software Engineering', author: ' Frederick P', count: 1 },
  { bookName: 'JavaScript-The Good Parts', description: ' Become a expert in Javascript ', author: 'Douglas Crockford', count: 6 },
  { bookName: 'The C Programming Language', description: 'Learning C programming basic', author: 'Dennis M. Ritchie', count: 12 },
  { bookName: 'Introduction to Algorithms', description: 'This title covers a broad range of algorithms in depth', author: 'Thomas', count: 1 },
  { bookName: 'Coders at Work', description: 'Reflections on the Craft of Programming', author: 'Peter Seibel', count: 2 },
  { bookName: 'Isomorphic JavaScript Web Development', description: 'Advanced JavaScript programming techniques', author: 'Tomas', count: 3 },
  { bookName: 'React for Real', description: 'Use React to create highly interactive web pages faster and with fewer errors', author: 'Ludovico Fischer', count: 1 },
  { bookName: 'The Road to learn React', description: 'The Road to learn React teaches you the fundamentals of React', author: 'Robin Wieruch', count: 1 }


  ],
  uiState: {
    //Create
    openFormDialog: false,
    //Update
    openEditDialog: false,
    articleToEdit: {},
    
  }
};
const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    //-----------------CREAT----------------------------

    case ADD_ARTICLE:
      var matchedIndex = [];
      state.articles.map((art, index) => {
        if (art.bookName === action.payload.bookName && art.author === action.payload.author) {
          matchedIndex.push(index);
        }
      });

      if (matchedIndex.length == 0) {
        action.payload.count = 1;
        return {
          ...state,
          articles: [...state.articles, action.payload]
        };
      }
      else {
        ++state.articles[matchedIndex[0]].count;
        return {
          ...state,
          articles: [...state.articles]
        }
      }

    case OPEN_FORM:

      return {
        ...state,
        uiState: {
          ...state.uiState,
          openFormDialog: true
        }
      };

    case CLOSE_FORM:

      return {
        ...state,
        uiState: {
          ...state.uiState,
          openFormDialog: false
        }
      };
    //----------------Get a Book------------------
    case UPDATE_ARTICLE:

      let bkIndex = state.articles.findIndex(bk => bk.bookName === action.payload.bookName);
       --state.articles[bkIndex].count

      return {
        ...state,
        articles: [...state.articles]
      };

    case OPEN_EDIT_FORM:
      
      return {
        ...state,
        uiState: {
          ...state.uiState,
          openEditDialog: true
        }
      };

    case CLOSE_EDIT_FORM:

      return {
        ...state,
        uiState: {
          ...state.uiState,
          openEditDialog: false
        }
      };

 
    default:
      return state;
  }
};
export default rootReducer;
